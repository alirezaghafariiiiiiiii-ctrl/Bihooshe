// Self-contained test: starts a mock OpenRouter + the server, checks the automatic tool loop.
const http = require('http');
const { spawn } = require('child_process');
const path = require('path');

const mock = http.createServer((req, res) => {
  let b = '';
  req.on('data', (d) => (b += d));
  req.on('end', () => {
    const j = JSON.parse(b);
    res.writeHead(200, { 'Content-Type': 'text/event-stream' });
    const w = (o) => res.write('data: ' + JSON.stringify(o) + '\n\n');
    if (!j.messages.some((m) => m.role === 'tool')) {
      w({ choices: [{ delta: { content: 'بذار حساب کنم. ' } }] });
      w({ choices: [{ delta: { tool_calls: [{ index: 0, id: 'c1', function: { name: 'run_python', arguments: '{"code":"print(sum(range(101)))"}' } }] } }] });
      w({ choices: [{ delta: { tool_calls: [{ index: 1, id: 'c2', function: { name: 'calculate', arguments: '{"expression":"sqrt(16)*2^3"}' } }] } }] });
      w({ choices: [{ delta: { tool_calls: [{ index: 2, id: 'c3', function: { name: 'run_javascript', arguments: '{"code":"console.log([3,1,2].sort().join())"}' } }] } }] });
      w({ choices: [{ delta: { tool_calls: [{ index: 3, id: 'c4', function: { name: 'get_datetime', arguments: '{"timezone":"Asia/Tehran"}' } }] } }] });
      w({ choices: [{ delta: { tool_calls: [{ index: 4, id: 'c5', function: { name: 'fetch_url', arguments: '{"url":"http://127.0.0.1:1/"}' } }] } }] });
    } else {
      w({ choices: [{ delta: { content: 'نتیجه: ' + j.messages.filter((m) => m.role === 'tool').map((m) => m.content.split('\n')[0]).join(' | ') } }] });
    }
    res.write('data: [DONE]\n\n');
    res.end();
  });
});

mock.listen(3918, () => {
  const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, OPENROUTER_API_KEY: 'test', OPENROUTER_BASE: 'http://localhost:3918', PORT: '3917' },
    stdio: 'ignore',
  });
  const done = (code) => { srv.kill(); mock.close(); process.exit(code); };
  setTimeout(async () => {
    try {
      const r = await fetch('http://localhost:3917/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [{ role: 'user', content: 'hi' }], tools: true }),
      });
      const text = await r.text();
      const events = text.split('\n\n').filter(Boolean).map((l) => JSON.parse(l.slice(5)));
      for (const e of events) console.log(e.type, e.name || '', (e.result || e.text || '').toString().slice(0, 90).replace(/\n/g, ' ⏎ '));
      const res = events.filter((e) => e.type === 'tool_result');
      const ok =
        res.length === 5 &&
        res[0].result.trim() === '5050' && res[1].result === '32' && res[2].result.trim() === '1,2,3' &&
        /Asia|\+0330|Persian/.test(res[3].result) && res[4].ok === false && events.at(-1).type === 'done';
      console.log(ok ? '\nPASS' : '\nFAIL');
      done(ok ? 0 : 1);
    } catch (e) { console.error(e); done(1); }
  }, 900);
});
