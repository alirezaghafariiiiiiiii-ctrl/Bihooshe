// AI Host — zero-dependency Node server (Node 18+)
// Proxies OpenRouter, runs an automatic tool-calling loop, serves the web app (PWA).
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const dns = require('dns').promises;
const net = require('net');
const { spawn } = require('child_process');

// ---------- tiny .env loader ----------
try {
  const envFile = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  for (const line of envFile.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
  }
} catch {}

const PORT = Number(process.env.PORT || 3000);
const KEY = process.env.OPENROUTER_API_KEY || '';
const DEFAULT_MODEL = process.env.DEFAULT_MODEL || 'openai/gpt-4o-mini';
const APP_PASSWORD = process.env.APP_PASSWORD || '';
const ENABLE_CODE_TOOLS = (process.env.ENABLE_CODE_TOOLS || 'true') !== 'false';
const MAX_ROUNDS = 8;
const PUBLIC = path.join(__dirname, 'public');
const OR = process.env.OPENROUTER_BASE || 'https://openrouter.ai/api/v1';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.png': 'image/png',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};

// ---------- tools ----------
const TOOLS = [
  {
    type: 'function',
    function: {
      name: 'run_python',
      description: 'Execute Python 3 code and return stdout/stderr. Use for calculations, data processing, algorithms, and anything that needs exact results. Print what you want to see.',
      parameters: { type: 'object', properties: { code: { type: 'string', description: 'Python source code' } }, required: ['code'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'run_javascript',
      description: 'Execute JavaScript (Node.js) code and return console output. Use console.log to print results.',
      parameters: { type: 'object', properties: { code: { type: 'string', description: 'JavaScript source code' } }, required: ['code'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'web_search',
      description: 'Search the web and return top results (title, url, snippet). Use for current events or facts you are unsure about.',
      parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'fetch_url',
      description: 'Download a web page and return its readable text (truncated).',
      parameters: { type: 'object', properties: { url: { type: 'string', description: 'http(s) URL' } }, required: ['url'] },
    },
  },
  {
    type: 'function',
    function: {
      name: 'get_datetime',
      description: 'Get the current date and time, optionally in an IANA timezone (e.g. Asia/Tehran). Also returns the Persian (Jalali) date.',
      parameters: { type: 'object', properties: { timezone: { type: 'string' } } },
    },
  },
  {
    type: 'function',
    function: {
      name: 'calculate',
      description: 'Evaluate a math expression, e.g. "sqrt(2)*3^2 + sin(pi/4)". Supports + - * / ^ % and Math functions.',
      parameters: { type: 'object', properties: { expression: { type: 'string' } }, required: ['expression'] },
    },
  },
];

function activeTools() {
  return TOOLS.filter((t) => ENABLE_CODE_TOOLS || !/^run_/.test(t.function.name));
}

const cap = (s, n = 8000) => (s.length > n ? s.slice(0, n) + `\n…[truncated ${s.length - n} chars]` : s);

function runProcess(cmd, args, code, ext, timeoutMs = 15000) {
  return new Promise((resolve) => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aihost-'));
    const file = path.join(dir, 'main' + ext);
    fs.writeFileSync(file, code);
    let out = '';
    let killed = false;
    const child = spawn(cmd, [...args, file], { cwd: dir, env: { PATH: process.env.PATH, HOME: dir, LANG: 'C.UTF-8' } });
    const timer = setTimeout(() => { killed = true; child.kill('SIGKILL'); }, timeoutMs);
    const onData = (d) => { if (out.length < 20000) out += d.toString(); };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('error', (e) => { clearTimeout(timer); resolve(`Failed to start ${cmd}: ${e.message}`); });
    child.on('close', (c) => {
      clearTimeout(timer);
      fs.rm(dir, { recursive: true, force: true }, () => {});
      resolve(cap(out.trim() || '(no output)') + (killed ? `\n[killed: exceeded ${timeoutMs / 1000}s]` : c ? `\n[exit code ${c}]` : ''));
    });
  });
}

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 10 || a === 127 || a === 0 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
  }
  const v = ip.toLowerCase();
  return v === '::1' || v === '::' || v.startsWith('fc') || v.startsWith('fd') || v.startsWith('fe80') || v.startsWith('::ffff:');
}

async function safeFetch(url, opts = {}) {
  const u = new URL(url);
  if (!/^https?:$/.test(u.protocol)) throw new Error('only http/https URLs are allowed');
  const addrs = await dns.lookup(u.hostname, { all: true });
  if (addrs.some((a) => isPrivateIp(a.address))) throw new Error('private/internal addresses are blocked');
  return fetch(u, { ...opts, redirect: 'follow', signal: AbortSignal.timeout(12000), headers: { 'User-Agent': 'Mozilla/5.0 (AI-Host)', ...(opts.headers || {}) } });
}

function htmlToText(html) {
  return html
    .replace(/<(script|style|noscript|svg)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<br\s*\/?>|<\/(p|div|h[1-6]|li|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n\n').trim();
}

function jalali(date, tz) {
  try {
    return new Intl.DateTimeFormat('fa-IR-u-ca-persian', { dateStyle: 'full', timeStyle: 'medium', timeZone: tz }).format(date);
  } catch { return ''; }
}

const toolImpl = {
  async run_python({ code }) { return runProcess('python3', ['-I'], String(code || ''), '.py'); },
  async run_javascript({ code }) { return runProcess(process.execPath, [], String(code || ''), '.js'); },
  async fetch_url({ url }) {
    const r = await safeFetch(String(url));
    const ct = r.headers.get('content-type') || '';
    const body = await r.text();
    return cap(`HTTP ${r.status}\n` + (/html/i.test(ct) ? htmlToText(body) : body));
  },
  async web_search({ query }) {
    const r = await safeFetch('https://html.duckduckgo.com/html/?q=' + encodeURIComponent(String(query)));
    const html = await r.text();
    const results = [];
    const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>[\s\S]*?class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
    let m;
    while ((m = re.exec(html)) && results.length < 6) {
      let href = m[1];
      const q = href.match(/uddg=([^&]+)/);
      if (q) href = decodeURIComponent(q[1]);
      results.push(`${results.length + 1}. ${htmlToText(m[2])}\n   ${href}\n   ${htmlToText(m[3])}`);
    }
    return results.join('\n\n') || 'No results found.';
  },
  async get_datetime({ timezone } = {}) {
    const now = new Date();
    const tz = timezone || undefined;
    let local;
    try { local = now.toLocaleString('en-GB', { timeZone: tz, hour12: false, dateStyle: 'full', timeStyle: 'long' }); }
    catch { return `Invalid timezone: ${timezone}`; }
    return `ISO (UTC): ${now.toISOString()}\nLocal: ${local}\nPersian: ${jalali(now, tz)}`;
  },
  async calculate({ expression }) {
    const src = String(expression || '').replace(/\^/g, '**');
    if (!/^[\d\s+\-*/%().,a-zA-Z_]*$/.test(src)) return 'Invalid characters in expression';
    const names = Object.getOwnPropertyNames(Math);
    const ids = src.match(/[a-zA-Z_]+/g) || [];
    if (ids.some((i) => !names.includes(i))) return 'Only Math functions/constants are allowed';
    const fn = new Function(...names, `"use strict"; return (${src});`);
    return String(fn(...names.map((n) => Math[n])));
  },
};

async function runTool(name, argsJson) {
  let args = {};
  try { args = argsJson ? JSON.parse(argsJson) : {}; } catch { return { ok: false, text: 'Invalid JSON arguments' }; }
  const impl = toolImpl[name];
  if (!impl || !activeTools().some((t) => t.function.name === name)) return { ok: false, text: `Unknown or disabled tool: ${name}` };
  try { return { ok: true, text: await impl(args) }; }
  catch (e) { return { ok: false, text: 'Error: ' + (e.message || e) }; }
}

// ---------- HTTP helpers ----------
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req, limit = 4_000_000) {
  return new Promise((resolve, reject) => {
    let b = '';
    req.on('data', (d) => { b += d; if (b.length > limit) { reject(new Error('body too large')); req.destroy(); } });
    req.on('end', () => resolve(b));
    req.on('error', reject);
  });
}
function authorized(req) {
  return !APP_PASSWORD || req.headers['x-app-password'] === APP_PASSWORD;
}

let modelCache = { at: 0, data: [] };
async function getModels() {
  if (Date.now() - modelCache.at < 3600_000 && modelCache.data.length) return modelCache.data;
  const r = await fetch(OR + '/models', { signal: AbortSignal.timeout(15000) });
  const j = await r.json();
  const data = (j.data || []).map((m) => ({
    id: m.id, name: m.name || m.id, ctx: m.context_length || 0,
    tools: (m.supported_parameters || []).includes('tools'),
    free: m.pricing && Number(m.pricing.prompt) === 0 && Number(m.pricing.completion) === 0,
  })).sort((a, b) => a.name.localeCompare(b.name));
  modelCache = { at: Date.now(), data };
  return data;
}

// ---------- chat with tool loop ----------
async function chat(req, res) {
  let body;
  try { body = JSON.parse(await readBody(req)); } catch { return json(res, 400, { error: 'bad request' }); }
  const key = KEY || (req.headers['x-openrouter-key'] || '');
  if (!key) return json(res, 400, { error: 'OPENROUTER_API_KEY is not set on the server (.env).' });

  res.writeHead(200, { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  const send = (o) => { if (!res.writableEnded) res.write(`data: ${JSON.stringify(o)}\n\n`); };
  const ac = new AbortController();
  res.on('close', () => ac.abort());

  const model = body.model || DEFAULT_MODEL;
  const useTools = body.tools !== false;
  const messages = [];
  if (body.system) messages.push({ role: 'system', content: String(body.system) });
  messages.push(...(body.messages || []));

  try {
    for (let round = 0; round < MAX_ROUNDS; round++) {
      const payload = { model, messages, stream: true };
      if (useTools) { payload.tools = activeTools(); payload.tool_choice = 'auto'; }
      const r = await fetch(OR + '/chat/completions', {
        method: 'POST', signal: ac.signal,
        headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json', 'HTTP-Referer': 'http://localhost', 'X-Title': 'AI Host' },
        body: JSON.stringify(payload),
      });
      if (!r.ok) {
        let msg = await r.text();
        try { msg = JSON.parse(msg).error.message || msg; } catch {}
        send({ type: 'error', message: `OpenRouter ${r.status}: ${msg}` });
        return res.end();
      }

      let content = '';
      const calls = [];
      const decoder = new TextDecoder();
      let buf = '';
      for await (const chunk of r.body) {
        buf += decoder.decode(chunk, { stream: true });
        let idx;
        while ((idx = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, idx).trim();
          buf = buf.slice(idx + 1);
          if (!line.startsWith('data:')) continue;
          const data = line.slice(5).trim();
          if (!data || data === '[DONE]') continue;
          let j; try { j = JSON.parse(data); } catch { continue; }
          if (j.error) { send({ type: 'error', message: j.error.message || 'stream error' }); continue; }
          const d = j.choices && j.choices[0] && j.choices[0].delta;
          if (!d) continue;
          if (d.content) { content += d.content; send({ type: 'delta', text: d.content }); }
          for (const tc of d.tool_calls || []) {
            const i = tc.index ?? 0;
            calls[i] = calls[i] || { id: '', name: '', args: '' };
            if (tc.id) calls[i].id = tc.id;
            if (tc.function && tc.function.name) calls[i].name += tc.function.name;
            if (tc.function && tc.function.arguments) calls[i].args += tc.function.arguments;
          }
        }
      }

      const real = calls.filter(Boolean);
      if (!real.length) { send({ type: 'done' }); return res.end(); }

      real.forEach((c, i) => { if (!c.id) c.id = `call_${round}_${i}`; });
      messages.push({
        role: 'assistant', content: content || null,
        tool_calls: real.map((c) => ({ id: c.id, type: 'function', function: { name: c.name, arguments: c.args || '{}' } })),
      });
      for (const c of real) {
        send({ type: 'tool_start', id: c.id, name: c.name, args: c.args });
        const out = await runTool(c.name, c.args);
        send({ type: 'tool_result', id: c.id, ok: out.ok, result: cap(out.text, 4000) });
        messages.push({ role: 'tool', tool_call_id: c.id, content: out.text });
      }
    }
    send({ type: 'error', message: 'Reached the tool-call limit.' });
    res.end();
  } catch (e) {
    if (!ac.signal.aborted) send({ type: 'error', message: e.message || String(e) });
    res.end();
  }
}

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/api/config') {
      return json(res, 200, { hasKey: !!KEY, defaultModel: DEFAULT_MODEL, needsPassword: !!APP_PASSWORD, codeTools: ENABLE_CODE_TOOLS, tools: activeTools().map((t) => t.function.name) });
    }
    if (url.pathname.startsWith('/api/')) {
      if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });
      if (url.pathname === '/api/models') return json(res, 200, await getModels());
      if (url.pathname === '/api/chat' && req.method === 'POST') return chat(req, res);
      return json(res, 404, { error: 'not found' });
    }
    let p = decodeURIComponent(url.pathname);
    if (p === '/') p = '/index.html';
    const file = path.normalize(path.join(PUBLIC, p));
    if (!file.startsWith(PUBLIC) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('Not found'); }
    const ext = path.extname(file);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': p === '/sw.js' ? 'no-cache' : 'public, max-age=300' });
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    if (!res.headersSent) json(res, 500, { error: e.message });
    else res.end();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  AI Host running → http://localhost:${PORT}`);
  console.log(`  OpenRouter key: ${KEY ? 'loaded ✓' : 'MISSING — add OPENROUTER_API_KEY to .env'}`);
  console.log(`  Tools: ${activeTools().map((t) => t.function.name).join(', ')}`);
  if (!APP_PASSWORD) console.log('  Tip: set APP_PASSWORD in .env before sharing the site publicly.\n');
});
