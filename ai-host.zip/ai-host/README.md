# آریا — AI Host

Zero-dependency Node server + stylish Persian PWA on top of OpenRouter.
Features: streaming chat, model picker, voice conversation, automatic tools
(Python, JavaScript, web search, page fetch, datetime/Jalali, calculator), installable app.

## Run
    cp .env.example .env     # then put your OpenRouter key in .env
    node server.js           # http://localhost:3000

## Deploy as a public website
Use the included Dockerfile (Render, Railway, Fly.io…). Set env vars OPENROUTER_API_KEY,
APP_PASSWORD (required for public sites) and ENABLE_CODE_TOOLS=false unless you trust every user.

## App
Open the site in Chrome → menu → "Install app" (or the button in the sidebar).
