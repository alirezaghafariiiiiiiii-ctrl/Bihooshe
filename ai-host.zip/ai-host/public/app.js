'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set: (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

const DEFAULT_SYSTEM = 'تو «آریا» هستی، یک دستیار هوشمند، صمیمی و دقیق. به زبان کاربر پاسخ بده (پیش‌فرض فارسی). وقتی محاسبه، کد، تاریخ/ساعت یا اطلاعات به‌روز لازم بود، خودت از ابزارها استفاده کن و نتیجه را توضیح بده.';
const VOICE_HINT = '\n\nکاربر دارد با صدا صحبت می‌کند. کوتاه، طبیعی و محاوره‌ای جواب بده؛ بدون مارک‌دان، فهرست و کد (مگر صراحتاً بخواهد).';

let cfg = { defaultModel: 'openai/gpt-4o-mini', needsPassword: false };
let settings = Object.assign({ model: null, system: DEFAULT_SYSTEM, lang: 'auto', rate: 1, autoRead: false, theme: 'auto', tools: true, pw: '' }, store.get('settings', {}));
let convs = store.get('convs', []);
let currentId = store.get('currentId', null);
let models = [];
let abortCtl = null;
let busy = false;

const save = () => { store.set('convs', convs.slice(0, 80)); store.set('currentId', currentId); store.set('settings', settings); };
const cur = () => convs.find((c) => c.id === currentId);
const uid = () => Math.random().toString(36).slice(2, 10);
const toast = (t) => { const el = $('#toast'); el.textContent = t; el.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => (el.hidden = true), 2600); };
const hdr = () => ({ 'Content-Type': 'application/json', ...(settings.pw ? { 'x-app-password': settings.pw } : {}) });

/* ---------- markdown ---------- */
const esc = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
function inline(s) {
  s = esc(s);
  const codes = [];
  s = s.replace(/`([^`\n]+)`/g, (_, c) => { codes.push(c); return `\u0000${codes.length - 1}\u0000`; });
  s = s.replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>').replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<i>$2</i>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
    .replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g, '$1<a href="$2" target="_blank" rel="noopener">$2</a>');
  return s.replace(/\u0000(\d+)\u0000/g, (_, i) => `<code>${codes[i]}</code>`);
}
function md(src) {
  const blocks = [];
  src = src.replace(/```(\w*)\n?([\s\S]*?)(```|$)/g, (_, lang, code) => {
    blocks.push(`<div class="codeblock"><div class="bar"><span>${esc(lang || 'code')}</span><button data-copy>کپی</button></div><pre><code>${esc(code.replace(/\n$/, ''))}</code></pre></div>`);
    return `\n\u0001${blocks.length - 1}\u0001\n`;
  });
  const lines = src.split('\n');
  let out = '', list = null, para = [], table = [];
  const flushP = () => { if (para.length) { out += `<p>${para.map(inline).join('<br>')}</p>`; para = []; } };
  const flushL = () => { if (list) { out += `</${list}>`; list = null; } };
  const flushT = () => {
    if (!table.length) return;
    const rows = table.map((r) => r.replace(/^\||\|$/g, '').split('|').map((c) => c.trim()));
    const head = rows[0], body = rows.slice(2);
    out += `<table><thead><tr>${head.map((c) => `<th>${inline(c)}</th>`).join('')}</tr></thead><tbody>${body.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    table = [];
  };
  for (const raw of lines) {
    const line = raw.trimEnd();
    let m;
    if ((m = line.match(/^\u0001(\d+)\u0001$/))) { flushP(); flushL(); flushT(); out += blocks[m[1]]; continue; }
    if (/^\s*\|.*\|\s*$/.test(line)) { flushP(); flushL(); table.push(line); continue; } else flushT();
    if (!line.trim()) { flushP(); flushL(); continue; }
    if ((m = line.match(/^(#{1,3})\s+(.*)/))) { flushP(); flushL(); out += `<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`; continue; }
    if ((m = line.match(/^>\s?(.*)/))) { flushP(); flushL(); out += `<blockquote>${inline(m[1])}</blockquote>`; continue; }
    if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { flushP(); if (list !== 'ul') { flushL(); out += '<ul>'; list = 'ul'; } out += `<li>${inline(m[1])}</li>`; continue; }
    if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { flushP(); if (list !== 'ol') { flushL(); out += '<ol>'; list = 'ol'; } out += `<li>${inline(m[1])}</li>`; continue; }
    flushL(); para.push(line);
  }
  flushP(); flushL(); flushT();
  return out;
}

/* ---------- rendering ---------- */
const messagesEl = $('#messages');
const scrollDown = () => { messagesEl.scrollTop = messagesEl.scrollHeight; };

function toolCard(t) {
  const d = document.createElement('details');
  d.className = 'tool' + (t.result == null ? '' : t.ok ? ' done' : ' fail');
  d.dataset.id = t.id;
  let args = t.args || '';
  try { const o = JSON.parse(args); args = o.code || o.query || o.url || o.expression || o.timezone || JSON.stringify(o, null, 2); } catch {}
  const label = { run_python: 'اجرای پایتون', run_javascript: 'اجرای جاوااسکریپت', web_search: 'جستجوی وب', fetch_url: 'خواندن صفحه وب', get_datetime: 'تاریخ و ساعت', calculate: 'محاسبه' }[t.name] || t.name;
  d.innerHTML = `<summary><span class="dot"></span>🛠 ${esc(label)}${t.result == null ? ' …' : ''}</summary><pre></pre>`;
  d.querySelector('pre').textContent = (args ? args + '\n' : '') + (t.result != null ? '\n── نتیجه ──\n' + t.result : '');
  return d;
}

function renderMsg(m, idx) {
  const row = document.createElement('div');
  row.className = 'msg ' + (m.role === 'user' ? 'user' : 'ai');
  if (m.role === 'user') {
    row.innerHTML = '<div class="bubble"></div>';
    row.firstChild.textContent = m.content;
  } else {
    row.innerHTML = '<div class="avatar">✦</div><div class="body"><div class="tools"></div><div class="md"></div><div class="actions"></div></div>';
    (m.tools || []).forEach((t) => $('.tools', row).append(toolCard(t)));
    fillAI(row, m);
  }
  return row;
}
function fillAI(row, m, streaming) {
  const md_ = $('.md', row);
  if (m.error) md_.innerHTML = (m.content ? md(m.content) : '') + `<div class="err">${esc(m.error)}</div>`;
  else if (!m.content && streaming) md_.innerHTML = '<div class="typing"><b></b><b></b><b></b></div>';
  else md_.innerHTML = md(m.content || '');
  const act = $('.actions', row);
  act.innerHTML = '';
  if (!streaming && m.content) {
    const copy = Object.assign(document.createElement('button'), { textContent: '⧉ کپی' });
    copy.onclick = () => { navigator.clipboard?.writeText(m.content); toast('کپی شد'); };
    const say = Object.assign(document.createElement('button'), { textContent: '🔊 بخوان' });
    say.onclick = () => (speechSynthesis.speaking ? speechSynthesis.cancel() : speak(m.content));
    act.append(copy, say);
  }
}
function renderAll() {
  const c = cur();
  $$('.msg', messagesEl).forEach((n) => n.remove());
  $('#empty').hidden = !!(c && c.messages.length);
  (c ? c.messages : []).forEach((m, i) => messagesEl.append(renderMsg(m, i)));
  renderConvList();
  scrollDown();
}
function renderConvList() {
  const el = $('#convList');
  el.innerHTML = '';
  convs.forEach((c) => {
    const d = document.createElement('div');
    d.className = 'conv' + (c.id === currentId ? ' active' : '');
    d.innerHTML = '<span></span><button aria-label="حذف">🗑</button>';
    $('span', d).textContent = c.title || 'گفتگوی جدید';
    d.onclick = (e) => {
      if (e.target.closest('button')) { convs = convs.filter((x) => x.id !== c.id); if (currentId === c.id) currentId = convs[0]?.id || null; save(); renderAll(); return; }
      currentId = c.id; save(); renderAll(); document.body.classList.remove('menu-open');
    };
    el.append(d);
  });
}
messagesEl.addEventListener('click', (e) => {
  const b = e.target.closest('[data-copy]');
  if (b) { navigator.clipboard?.writeText($('code', b.closest('.codeblock')).textContent); b.textContent = '✓ کپی شد'; setTimeout(() => (b.textContent = 'کپی'), 1400); }
});

/* ---------- chat ---------- */
function newChat() { currentId = null; save(); renderAll(); $('#input').focus(); }

async function send(text, { voice = false } = {}) {
  text = text.trim();
  if (!text || busy) return;
  let c = cur();
  if (!c) { c = { id: uid(), title: text.slice(0, 40), messages: [] }; convs.unshift(c); currentId = c.id; }
  c.messages.push({ role: 'user', content: text });
  const ai = { role: 'assistant', content: '', tools: [] };
  c.messages.push(ai);
  save(); renderAll();
  const row = $$('.msg.ai', messagesEl).pop();
  fillAI(row, ai, true);
  setBusy(true);
  abortCtl = new AbortController();
  if (voice) setVoiceState('thinking', 'در حال فکر کردن…');

  const history = c.messages.slice(0, -1).filter((m) => m.content).map((m) => ({ role: m.role, content: m.content }));
  try {
    const r = await fetch('/api/chat', {
      method: 'POST', headers: hdr(), signal: abortCtl.signal,
      body: JSON.stringify({ model: settings.model || cfg.defaultModel, messages: history, tools: settings.tools, system: (settings.system || DEFAULT_SYSTEM) + (voice ? VOICE_HINT : '') }),
    });
    if (r.status === 401) { ai.error = 'رمز دسترسی نادرست است. از تنظیمات وارد کنید.'; throw new Error('auth'); }
    if (!r.ok) { const j = await r.json().catch(() => ({})); ai.error = j.error || 'خطا در ارتباط با سرور'; throw new Error('http'); }
    const reader = r.body.getReader(), dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        if (!chunk.startsWith('data:')) continue;
        let ev; try { ev = JSON.parse(chunk.slice(5)); } catch { continue; }
        if (ev.type === 'delta') { ai.content += ev.text; fillAI(row, ai, true); }
        else if (ev.type === 'tool_start') {
          const t = { id: ev.id, name: ev.name, args: ev.args, result: null };
          ai.tools.push(t); $('.tools', row).append(toolCard(t));
        } else if (ev.type === 'tool_result') {
          const t = ai.tools.find((x) => x.id === ev.id);
          if (t) { t.result = ev.result; t.ok = ev.ok; const old = $(`.tool[data-id="${CSS.escape(ev.id)}"]`, row); old.replaceWith(toolCard(t)); }
          // content generated before a tool call becomes part of the same message; add spacing
          if (ai.content && !ai.content.endsWith('\n')) ai.content += '\n\n';
        } else if (ev.type === 'error') ai.error = ev.message;
        scrollDown();
      }
    }
  } catch (e) {
    if (e.name === 'AbortError') ai.content += ai.content ? '' : '';
    else if (!ai.error) ai.error = 'ارتباط قطع شد: ' + e.message;
  }
  fillAI(row, ai, false);
  setBusy(false); abortCtl = null; save(); renderConvList(); scrollDown();

  if (voice && voiceOn) {
    if (ai.content) speak(ai.content, () => voiceOn && listen()); else { setVoiceState('listening', ai.error || 'پاسخی دریافت نشد'); setTimeout(() => voiceOn && listen(), 1500); }
  } else if (settings.autoRead && ai.content) speak(ai.content);
}

function setBusy(b) {
  busy = b;
  const s = $('#sendBtn');
  s.classList.toggle('stop', b); s.textContent = b ? '■' : '➤';
}

/* ---------- speech ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const isFa = (t) => (t.match(/[؀-ۿ]/g) || []).length > t.replace(/\s/g, '').length * 0.3;
const langFor = (t) => (settings.lang === 'auto' ? (isFa(t) ? 'fa-IR' : 'en-US') : settings.lang);

function clean(t) {
  return t.replace(/```[\s\S]*?```/g, ' (کد نمایش داده شد) ').replace(/`([^`]*)`/g, '$1').replace(/https?:\/\/\S+/g, ' لینک ')
    .replace(/[*#>_|~]/g, ' ').replace(/^\s*[-•]\s+/gm, '').replace(/\s+/g, ' ').trim();
}
function pickVoice(lang) {
  const vs = speechSynthesis.getVoices();
  return vs.find((v) => v.lang.replace('_', '-').toLowerCase() === lang.toLowerCase()) || vs.find((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2).toLowerCase()));
}
function speak(text, onEnd) {
  speechSynthesis.cancel();
  const t = clean(text);
  if (!t) return onEnd && onEnd();
  const parts = t.match(/[^.!؟?۔\n]+[.!؟?۔]?/g) || [t];
  const chunks = []; let acc = '';
  for (const p of parts) { if ((acc + p).length > 180) { if (acc) chunks.push(acc); acc = p; } else acc += p; }
  if (acc) chunks.push(acc);
  if (voiceOn) setVoiceState('speaking', 'در حال صحبت…');
  chunks.forEach((ch, i) => {
    const u = new SpeechSynthesisUtterance(ch);
    u.lang = langFor(ch); u.rate = Number(settings.rate) || 1;
    const v = pickVoice(u.lang); if (v) u.voice = v;
    if (i === chunks.length - 1) { u.onend = () => onEnd && onEnd(); u.onerror = () => onEnd && onEnd(); }
    speechSynthesis.speak(u);
  });
}

// dictation (mic in composer)
let dictRec = null;
function dictate() {
  if (!SR) return toast('مرورگر شما تشخیص گفتار را پشتیبانی نمی‌کند (Chrome را امتحان کنید)');
  if (dictRec) { dictRec.stop(); return; }
  const r = dictRec = new SR();
  r.lang = settings.lang === 'auto' ? 'fa-IR' : settings.lang; r.interimResults = true; r.continuous = false;
  const base = $('#input').value; $('#micBtn').classList.add('rec');
  r.onresult = (e) => { $('#input').value = (base + ' ' + [...e.results].map((x) => x[0].transcript).join(' ')).trim(); autosize(); };
  r.onend = r.onerror = () => { $('#micBtn').classList.remove('rec'); dictRec = null; };
  r.start();
}

// voice conversation
let voiceOn = false, voiceRec = null;
function setVoiceState(s, label) { $('#voice').dataset.s = s; $('#vstate').textContent = label; }
function openVoice() {
  if (!SR) return toast('مکالمه صوتی نیاز به مرورگر Chrome/Edge/Safari دارد');
  voiceOn = true; $('#voice').hidden = false; $('#vtext').textContent = ''; listen();
}
function closeVoice() {
  voiceOn = false; $('#voice').hidden = true;
  try { voiceRec && voiceRec.abort(); } catch {}
  speechSynthesis.cancel(); abortCtl && abortCtl.abort();
}
function listen() {
  if (!voiceOn || busy) return;
  try { voiceRec && voiceRec.abort(); } catch {}
  speechSynthesis.cancel();
  const r = voiceRec = new SR();
  r.lang = settings.lang === 'auto' ? 'fa-IR' : settings.lang; r.interimResults = true; r.continuous = false;
  let finalText = '', heard = false;
  setVoiceState('listening', 'در حال گوش دادن…');
  r.onresult = (e) => {
    heard = true;
    const txt = [...e.results].map((x) => x[0].transcript).join(' ');
    $('#vtext').textContent = txt;
    if (e.results[e.results.length - 1].isFinal) finalText = txt;
  };
  r.onerror = (e) => {
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { toast('اجازهٔ میکروفون داده نشده'); closeVoice(); }
  };
  r.onend = () => {
    if (voiceRec !== r || !voiceOn) return;
    if (finalText.trim()) send(finalText, { voice: true });
    else if (!busy) setTimeout(() => voiceOn && !busy && listen(), heard ? 100 : 400);
  };
  try { r.start(); } catch {}
}
$('#orb').onclick = () => {
  if (busy) { abortCtl && abortCtl.abort(); return; }
  if (speechSynthesis.speaking) { speechSynthesis.cancel(); }
  listen();
};

/* ---------- models & settings ---------- */
async function loadModels() {
  try {
    const r = await fetch('/api/models', { headers: hdr() });
    if (r.ok) models = await r.json();
  } catch {}
}
function renderModels() {
  const q = $('#modelSearch').value.toLowerCase().trim(), onlyTools = $('#onlyTools').checked;
  const list = $('#modelList'); list.innerHTML = '';
  let items = models.filter((m) => (!onlyTools || m.tools) && (!q || (m.id + m.name).toLowerCase().includes(q)));
  if (!models.length) list.innerHTML = '<div class="hint">فهرست مدل‌ها بارگذاری نشد. می‌توانید نام مدل را دستی وارد کنید.</div>';
  items.slice(0, 120).forEach((m) => {
    const b = document.createElement('button');
    b.className = 'mitem' + (m.id === (settings.model || cfg.defaultModel) ? ' sel' : '');
    b.innerHTML = `<div><span></span>${m.free ? '<span class="badge">رایگان</span>' : ''}${m.tools ? '<span class="badge">ابزار</span>' : ''}<small></small></div>`;
    $('span', b).textContent = m.name; $('small', b).textContent = m.id;
    b.onclick = () => { settings.model = m.id; save(); updateModelChip(); $('#modelDlg').close(); };
    list.append(b);
  });
  if (q && !items.some((m) => m.id === q) && /\//.test(q)) {
    const b = document.createElement('button'); b.className = 'mitem'; b.textContent = `استفاده از «${q}»`;
    b.onclick = () => { settings.model = q; save(); updateModelChip(); $('#modelDlg').close(); }; list.prepend(b);
  }
}
function updateModelChip() {
  const id = settings.model || cfg.defaultModel;
  const m = models.find((x) => x.id === id);
  $('#modelName').textContent = m ? m.name.replace(/^[^:]+:\s*/, '') : id;
  $('#toolsToggle').classList.toggle('on', settings.tools);
}
function applyTheme() { document.documentElement.dataset.theme = settings.theme; }

function openSettings() {
  $('#setSystem').value = settings.system; $('#setLang').value = settings.lang; $('#setRate').value = settings.rate;
  $('#rateVal').textContent = settings.rate + '×'; $('#setAutoRead').checked = settings.autoRead; $('#setTheme').value = settings.theme;
  $('#pwRow').hidden = !cfg.needsPassword; $('#setPw').value = settings.pw || '';
  $('#settingsDlg').showModal();
}

/* ---------- wiring ---------- */
const input = $('#input');
function autosize() { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 180) + 'px'; }
input.addEventListener('input', autosize);
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && matchMedia('(hover:hover)').matches) { e.preventDefault(); $('#sendBtn').click(); } });
$('#sendBtn').onclick = () => {
  if (busy) { abortCtl && abortCtl.abort(); return; }
  const t = input.value; input.value = ''; autosize(); send(t);
};
$('#micBtn').onclick = dictate;
$('#voiceBtn').onclick = openVoice;
$('#voiceClose').onclick = closeVoice;
$('#newChat').onclick = () => { newChat(); document.body.classList.remove('menu-open'); };
$('#menuBtn').onclick = () => document.body.classList.add('menu-open');
$('#scrim').onclick = () => document.body.classList.remove('menu-open');
$('#modelChip').onclick = () => { $('#modelSearch').value = ''; renderModels(); $('#modelDlg').showModal(); };
$('#modelSearch').oninput = renderModels; $('#onlyTools').onchange = renderModels;
$('#toolsToggle').onclick = () => { settings.tools = !settings.tools; save(); updateModelChip(); toast(settings.tools ? 'ابزارهای خودکار روشن شد' : 'ابزارها خاموش شد'); };
$('#openSettings').onclick = openSettings;
$('#setRate').oninput = (e) => ($('#rateVal').textContent = e.target.value + '×');
$('#saveSettings').onclick = () => {
  Object.assign(settings, { system: $('#setSystem').value.trim() || DEFAULT_SYSTEM, lang: $('#setLang').value, rate: Number($('#setRate').value), autoRead: $('#setAutoRead').checked, theme: $('#setTheme').value, pw: $('#setPw').value });
  save(); applyTheme(); $('#settingsDlg').close(); loadModels().then(updateModelChip); toast('ذخیره شد');
};
$('#clearAll').onclick = () => { if (confirm('همهٔ گفتگوها حذف شود؟')) { convs = []; currentId = null; save(); renderAll(); $('#settingsDlg').close(); } };
$$('[data-close]').forEach((b) => (b.onclick = () => b.closest('dialog').close()));
$$('.suggest button').forEach((b) => (b.onclick = () => send(b.textContent)));
$$('dialog').forEach((d) => d.addEventListener('click', (e) => { if (e.target === d) d.close(); }));

let deferredInstall;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredInstall = e; $('#installBtn').hidden = false; });
$('#installBtn').onclick = async () => { if (!deferredInstall) return; deferredInstall.prompt(); await deferredInstall.userChoice; deferredInstall = null; $('#installBtn').hidden = true; };
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = () => {};

(async function init() {
  applyTheme();
  try { cfg = Object.assign(cfg, await (await fetch('/api/config')).json()); } catch {}
  if (!cfg.hasKey) toast('کلید OpenRouter در فایل .env تنظیم نشده');
  if (cfg.needsPassword && !settings.pw) { openSettings(); }
  renderAll(); updateModelChip();
  await loadModels(); updateModelChip();
})();
